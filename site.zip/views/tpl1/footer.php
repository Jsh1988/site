<?php defined("CATALOG") or die("Acces denied");?>
		<div id="block_footer">
				<ul>
					<li align="center">&copy; websimba.dp.ua, <?=date('Y')?>
						<p>интересные статьи</p>
					</li>
				</ul>

		</div>



	</div>

</body>
</html>