<?php defined("CATALOG") or die("Acces denied");?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>404 - такой страницы нет</title>
</head>
<body>
	<div class="404">
        <img src="<?=PATH?><?=VIEW?>img/404/404.png?>" alt="404" />
    </div>
</body>
</html>